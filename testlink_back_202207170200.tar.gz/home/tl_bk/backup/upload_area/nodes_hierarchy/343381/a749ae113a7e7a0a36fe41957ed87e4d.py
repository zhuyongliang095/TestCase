# $language = "Python"
# $interface = "1.0"

import random

crt.Screen.Synchronous = False
def add_apppolicy():
	crt.Screen.Send('conf t\r')
	i=150
	while i < 190:
		crt.Screen.Send("app-policy "+str(i)+" \n")
		crt.Screen.Send("exit \n")
		i+=1
add_apppolicy()
