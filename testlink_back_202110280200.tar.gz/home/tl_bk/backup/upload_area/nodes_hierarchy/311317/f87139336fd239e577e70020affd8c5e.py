#!/usr/bin/python
from scapy.all import *

def get_dns_cache(sip,dip,dns,num):
    pcaps=[]
    if ( type(dip) == 'list' and type(sip) == 'list') :
        for i in range(num):
            pcaps.append(Ether()/IP(src=sip[i],dst=dip[i])/UDP()/DNS(rd=1,qd=DNSQR(qname=dns)))
    elif( type(dip) == 'list' and type(sip) != 'list') :
        for i in range(num):
            pcaps.append(Ether()/IP(src=src,dst=dip[i])/UDP()/DNS(rd=1,qd=DNSQR(qname=dns)))
    elif (type(dip) != 'list' and type(sip) == 'list') :
        for i in range(num):
            pcaps.append(Ether()/IP(src=src[i],dst=dip)/UDP()/DNS(rd=1,qd=DNSQR(qname=dns)))
    elif( type(dip) != 'list' and type(sip) != 'list') :
        for i in range(num):
            pcaps.append(Ether()/IP(src=sip,dst=dip)/UDP()/DNS(rd=1,qd=DNSQR(qname=dns)))
    return pcaps


def get_ip(ip,num):
    ip=ip.split(".")
    ip[3]=int(ip[3])+int(num)
    if ip[3] >= 255:
        ip[2]=int(ip[2])+1
        if ip[2] >=255 :
            ip[1]=int(ip[1])+1
            if [1] >= 255:
                ip[0]=int(ip[0])+1
    for i in range(len(ip)):
        ip[i]=str(ip[i])
    return '.'.join(ip)
 
def get_ips(ip,num):
    ip_list=[]
    for i in range(num):
        ip_list.append(get_ip(ip,i))
    return ip_list
    
def send_pcap(pcaps,inter,loop):
    sendp(pcaps,iface=inter,loop=loop)

if __name__ == '__main__' :
    num=20
    dst=get_ips('172.20.0.1',1)
    src=get_ips('172.20.0.10',num)
    dns_pcaps=get_dns_cache(src,dst,'www.baidu.com',num)
    send_pcap(dns_pcaps,'eth1',3)
