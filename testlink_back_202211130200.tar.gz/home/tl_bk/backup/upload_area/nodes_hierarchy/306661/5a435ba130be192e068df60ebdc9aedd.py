# $language = "Python"
# $interface = "1.0"
import random
import string
import cmath
crt.Screen.Synchronous = False

#先创建用户/用户组、地址/地址组、周期/绝对时间对象各100条，便于策略引用

#说明：由于策略加速在七元组各个条件都要测试，除了已给出的对象外，其他对象测试时可新建1-2条，放于所有策略之后，再进行匹配
#用户/用户组
def user():
	j=1
	i=1
	crt.Screen.Send('conf t'+'\r')
	while j < 101:
		crt.Screen.Send('user-local user-'+str(j)+'\r')               #用户对象
		crt.Screen.Send('enable bind'+'\r')
		crt.Screen.Send('bind ip address 3.3.32.'+str(i)+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		crt.Screen.Send('user-group user-grp-'+str(j)+'\r')			  #用户组
		crt.Screen.Send('member user-1'+'\r')
		crt.Screen.Send('exit'+'\r')
		j+=1
		i+=1
user()

#地址/地址组
def address():
	j=1
	i=1
	crt.Screen.Send('conf t'+'\r')
	while j <102:
		crt.Screen.Send('address addr-'+str(i)+'\r')					#地址对象
		crt.Screen.Send('host-address 33.33.1.'+str(j)+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Screen.Send('address-group adr_grp-'+str(i)+'\r')			#地址组
		crt.Screen.Send('address-object addr-1\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
		i+=1
address()

#绝对/周期时间
def time():
	j=1
	i=1
	crt.Screen.Send('conf t'+'\r')
	while j <101:
		crt.Screen.Send(' schedule onetime absolte-'+str(j)+'\r')				#绝对时间
		crt.Screen.Send('absolute 19-09-01 11:12:12 19-09-03 12:12:12'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
	while i <101:
		crt.Screen.Send(' schedule recurring round-'+str(i)+'\r')				#周期时间
		crt.Screen.Send('absolute 19-02-21 12:12:12 19-09-09 12:23:12'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		i+=1
time()


#################主要根据不同出入接口配置一定数量的策略加速；测试过程中可根据设备接口名称，自行在脚本中修改接口名称
####################以下策略接口均相同，进行出入接口测试时，可修改任意循环中的接口名称，创建后该接口对下会存在至少100条策略
#####################还需注意一点的是：该脚本中创建的策略id是从1开始，
######################如果待测设备上已有策略，要么清空设备上策略，要么修改脚本中策略id，每个循环中id数加100


#########################另加说明：ipv6策略在创建的时候只需将policy改为policy-v6，地址/对象引用相关的ipv6地址即可

def interface():
	j = 1
	i = 1
	crt.Screen.Send('end \r')
	crt.Screen.Send('conf t'+'\r')
	while j < 101:
		crt.Screen.Send('policy '+str(j)+' vlan101 ge0/1 addr-'+str(i)+' any any any any always permit'+'\r')			#源IP100条
		crt.Screen.Send('enable'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
		i+=1
	j = 101
	i = 1
	while j < 201:
		crt.Screen.Send('policy '+str(j)+' vlan101 ge0/1 any adr_grp-'+str(i)+' any any any always permit'+'\r')		#目的IP100条
		crt.Screen.Send('enable'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
		i+=1
	j = 201
	i = 1
	while j <301:
		crt.Screen.Send('policy '+str(j)+' vlan101 ge0/1 any any any user-'+str(i)+' any always permit'+'\r')		#用户100条
		crt.Screen.Send('enable'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
		i+=1
	j = 301
	i = 1
	while j < 401:
		crt.Screen.Send('policy '+str(j)+' any ge0/1 any any any user-grp-'+str(i)+' any always permit'+'\r')		#用户组100条
		crt.Screen.Send('enable'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
		i+=1
	j = 401	
	i = 1
	while j <501:
		crt.Screen.Send('policy '+str(j)+' any ge0/1 any any any any any absolte-'+str(i)+' permit'+'\r')			#绝对时间对象100条
		crt.Screen.Send('enable'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
		i+=1
	j = 501
	i = 1
	while j <601:
		crt.Screen.Send('policy '+str(j)+' vlan101 ge0/1 any any any any any round-'+str(i)+' permit'+'\r')			#周期时间对象100条
		crt.Screen.Send('enable'+'\r')
		crt.Screen.Send('exit'+'\r')
		crt.Sleep(10)
		j+=1
		i+=1
interface()