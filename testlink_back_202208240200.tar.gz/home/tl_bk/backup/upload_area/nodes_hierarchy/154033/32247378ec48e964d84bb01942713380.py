#!/usr/bin/env python
#-*- coding: utf-8 -*-
import socket
import time
import datetime
import random
import json
import gevent
from gevent.pool import Pool
from gevent.queue import Queue ,Empty 

def ip_change(startip='',count=None):
    ip=[startip]
    ip_old=startip.split('.')
    for i in range(count-1):
        ip_old[3]=int(ip_old[3])+1
        if int(ip_old[3]) == 255 :
            ip_old[3]=1
            ip_old[2]=int(ip_old[2])+1
            if int(ip_old[2]) == 255 :
                ip_old[2] = 1
                ip_old[1] = int(ip_old[1])+1
                if int(ip_old[1])==255:
                    ip_old[1] = 1
                    ip_old[0] = int(ip_old[0])+1
        for a in range(len(ip_old)):
            ip_old[a]=str(ip_old[a])
        ip.append('.'.join(ip_old))
    return ip


health_cpuinfo=range(0,50)
health_meminfo=range(0,80)
health_rx=range(0,2000)
health_tx=range(0,2000)
health_totalconn=range(0,1000)
health_newconn=range(0,100)
health_users=range(0,100)
health_txbps=range(0,1000)
health_rxbps=range(0,1000)

def get_health_send_data(ip):
    data=[]
    data.append('SerialNum=00020003-0004-0005-0006-%s'%str('{:p>4}{:p>4}{:p>4}'.format(ip.split('.')[-3],ip.split('.')[-2],ip.split('.')[-1])))
    data.append('GenTime=\"%s\"'%time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()))
    data.append('CpuInfo=%.2f'%random.choice(health_cpuinfo))
    data.append('MemInfo=%.2f'%random.choice(health_meminfo))
    rx=random.choice(health_rx)
    tx=random.choice(health_tx)
    data.append('rx=%ld'%rx)
    data.append('tx=%ld'%tx)
    data.append('rtx=%ld'%(int(rx)+int(tx)))
    data.append('tunl0_rxbps=%s'%random.choice(health_rxbps))
    data.append('tunl0_txbps=%s'%random.choice(health_txbps))
    data.append('mgt_rxbps=%s'%random.choice(health_rxbps))
    data.append('mgt_txbps=%s'%random.choice(health_txbps))
    data.append('ge0/0_rxbps=%s'%random.choice(health_rxbps))
    data.append('ge0/0_txbps=%s'%random.choice(health_txbps))
    data.append('TotalConn=%ld'%random.choice(health_totalconn))
    data.append('NewConn=%ld'%random.choice(health_newconn))
    health_starttime=datetime.datetime.now()
    health_endtime=datetime.datetime(2017,5,27,14,20,0)
    health_uptime=(health_starttime-health_endtime).seconds
    data.append('Uptime=%s'%(health_uptime))
    data.append('Users=%s'%random.choice(health_users))
    data.append('TunnelIp=%s'%ip)
    return ' '.join(data)
#     
# def get_health(ip_list):
#     for i in range(len(ip_list)):
#         get_health_send_data(ip_list[i])
#     print(get_health_send_data(ip_list[i]))
    
    
def send_log_bps(sock,bps=1000):
    loop_send = bps/10
    last_send = bps % 10
    s_time=time.time()
    for a in range(10):
        if a == 9 :
            loop_send+=last_send
        for num in range(loop_send):
            health_time='{} {:>2} {}'.format(time.strftime("%b",time.localtime()),time.localtime()[2],time.strftime("%H:%M:%S",time.localtime()))
            for data in get_health(ip_list):
                sock.send("<366>%s host SYSTEM_INFO: %s\n"%(health_time,data))
        end_time=time.time()-s_time
        if 0< end_time <= 0.1 :
            sleeptime=0.1-end_time
            gevent.sleep(sleeptime)
            #print("sleep time %s"%sleeptime)
            s_time=time.time() 

def send_log_total_time(cloud_ip,que,total_time=10,bps=1000):
    '''单进程发送日志，total_time 运行时间， bps 发送速率，日志条目数/s
    '''
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sock.connect((cloud_ip,514))
    start_time=ss_time=time.time()
    for t in range(total_time) :
        send_log_bps(sock,bps)
        #print("")
        que.put(bps)
        es_time=time.time()
        #print("send packet %s, used time %s"%(bps,es_time-ss_time))
        sleeptime=1-(es_time - ss_time)
        if 0< sleeptime :
            gevent.sleep(sleeptime)
        ss_time=time.time()
    sock.close()
    end_time=time.time()

def get_bps(que,total_time):
    for x in range(total_time):
        start_time=time.time()
        gevent.sleep(1)
        bps=0
        while not que.empty():
            bps+=int(que.get())
        end_time=time.time()
        print("total send packets %s\n total used time %.1s."%(bps,(end_time-start_time)))

def send_log_gevent(cloud_ip,total_time=10,bps=1000,concurrent=12):
    '''多进程并发发送log日志
    total_time 并发发送时间
    bps 每个进程的日志发送速率
    concurrent 并发数
    '''
    que=Queue()
    pool=Pool(concurrent+1)
    for x in range(concurrent):
        pool.spawn(send_log_total_time,cloud_ip,que,total_time,bps)
    pool.spawn(get_bps,que,total_time)
    pool.join()
    #gevent.joinall([ pool.spawn(send_log_total_time,total_time,bps) for x in range(concurrent) ])
    
def get_health(ip_list):
    return_data=[]
    for i in range(len(ip_list)):
        return_data.append(get_health_send_data(ip_list[i]))        
        #print(get_health_send_data(ip_list[i]))
    return return_data
    
#send_log_total_time(total_time=10,bps=5000)
cloud_ip='192.168.120.10'
ip_list=ip_change('5.5.5.1',100)
send_log_gevent(cloud_ip,total_time=60,bps=50,concurrent=100)

