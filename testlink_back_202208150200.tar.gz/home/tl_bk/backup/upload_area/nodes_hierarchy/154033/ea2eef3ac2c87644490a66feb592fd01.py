﻿#!/usr/bin/env python
#-*- coding: utf-8 -*-
# UDP Client - udpclient.py
# code by zhuyl
#from gevent import select
from gevent import monkey; monkey.patch_all()
import socket
import gevent
import sys
import time
import random
import struct
import json
import os
import signal
import pdb
import base64

#协议版本号，2对应未兼容之前实现。
CONST_VERSION_2 = 2
'''
协议版本号， 3对应消息体进行了base64编解码。
编码：
1. 绑定请求
2. 心跳报文
3. 授权请求
解码：
1. 授权响应
'''
CONST_VERSION_3 = 3

def ip_change(startip='',count=None):
    ip=[startip]
    ip_old=startip.split('.')
    for i in range(count-1):
        ip_old[3]=int(ip_old[3])+1
        if int(ip_old[3]) == 255 :
            ip_old[3]=1
            ip_old[2]=int(ip_old[2])+1
            if int(ip_old[2]) == 255 :
                ip_old[2] = 1
                ip_old[1] = int(ip_old[1])+1
                if int(ip_old[1])==255:
                    ip_old[1] = 1
                    ip_old[0] = int(ip_old[0])+1
        for a in range(len(ip_old)):
            ip_old[a]=str(ip_old[a])
        ip.append('.'.join(ip_old))
    return ip

def get_siteName(startSite='site.test.com',count=None):
    siteNames=[]
    for i in range(count):
        site=startSite.split('.')
        site[0]=site[0]+str(i)
        siteNames.append(".".join(site))
    return siteNames

class vfw_simulation():  #vfw 实例

    def __init__(self,ip,core,device,siteName,sock,agent_version):
        self.ip=ip
        self.sn='00020003-0004-0005-0006-'+str('{:p>4}{:p>4}{:p>4}'.format(ip.split('.')[-3],ip.split('.')[-2],ip.split('.')[-1]))
        self.status=0
        self.sessionID=0
        self.sequence=1
        self.runTime=time.time()
        self.smcRunTime=time.time()
        self.license='no license'
        self.core=core
        self.device=device
        self.siteName=siteName
        self.sock=sock
        self.version = agent_version

    def _pack_header(self):
        self.sequence=(self.sequence+1) if self.sequence <= 65535 else 1
        #self.sequence+=1
        #if self.sequence > 65535:
        #    self.sequence=0
        timestamp=time.time()
        reserved=self.device<<11
        header=struct.pack('!HbbHHif',self.version,self.command[0],self.command[1],self.sequence,reserved,self.sessionID,timestamp)
        return header
    
    def unpack_header(self,data,sock):
        command=[0,0]
        if len(data) == 16 :
            ver,command[0],command[1],sequence,reserved,sessionID,timestamp=struct.unpack('!HbbHHif',data)
        else :
            ver,command[0],command[1],sequence,reserved,sessionID,timestamp,cloud_data=struct.unpack('!HbbHHif%ds'%(len(data)-16),data)
        self.smcRunTime=time.time()
        #print('%s update smcRunTime %s self.smcRunTime:%s'%(time.strftime("%Y-%m-%d %H:%M:%S",time.gmtime()),sock.getsockname(),self.smcRunTime))
        if  command == [1,2] :  # 绑定应答报文
            self.sessionID=sessionID
            self.status = 1 #云端给绑定做应答，下次发送请求license
        elif command == [6,2] :  # update
            cloud_data = self.decode(cloud_data.decode('utf-8'))
            self.license = json.loads(cloud_data)
            self.status = 2  #license 更新后，只发送keepalive
        elif command == [6,3]: #收到云端发送的报活keepalive
            pass
            #self.smcRunTime=time.time()  #收到smc的应答报文，更新smc在线时间。
            #pass
        return self.send_pack(self.smcRunTime)
            
    def _send_bindcode(self):
        self.command=[1,1]
        data={"sn":self.sn, "bindCode":"aed995e7ce694c4287d9cd512e3d3229"}
        data = self.encode(json.dumps(data).encode('ascii'))
        return self._pack_header()+data
        
    def _send_licence_request(self):
        self.command=[6,1]
        coretxt={"core":self.core}
        coretxt = self.encode(json.dumps(coretxt).encode('ascii'))
        return self._pack_header()+coretxt

    def _send_device_notice(self):  #agent keepalive
        self.command=[2,1]
        dev_info={"siteName":self.siteName,
                  "hostName":"host",
                  "hostIP": self.ip, 
                  "version": "V1.1-R2.120161216", 
                  "uptime":str(int(time.time()-self.runTime)), 
                  "cpuInfo": {"total": "100.00", 
                              "used": "0.00"}, 
                  "memInfo": {"total": "1096636116", 
                              "used": "455400072"}, 
                  "nrConns": "30", 
                  "nrUsers": "52", 
                  "cycle": "10",
                  "modelName":"ASG-4500-Virtual",
                  "bindCode":"aed995e7ce694c4287d9cd512e3d3229",
                  'sn': self.sn}
        
        if self.status == 2 :
            dev_info["license"]=self.license
        dev_info = self.encode(json.dumps(dev_info).encode('ascii'))
        return self._pack_header()+dev_info
        
    def send_pack(self,smcRunTime):
        t=int(time.time()-smcRunTime)
        if t > 100 :  #smc长时间不发送keepalive报文。
            print("%s :status %d, [ %s no response %s ] self.time:%s"%(time.strftime("%Y-%m-%d %H:%M:%S",time.gmtime()),self.status,t,self.sock.getsockname(),self.smcRunTime))
        if int(time.time()-smcRunTime) > 1200 :  #smc长时间不发送keepalive报文，则认为smc不在线，重新请求绑定。
            self.__init__(self.ip,self.core,self.device,self.siteName,self.sock)
        if self.status == 0 : # 请求绑定
            return self._send_bindcode()
        elif self.status == 1:  # 请求license
            return self._send_licence_request(),self._send_device_notice()
        elif self.status == 2: # 只发送keepalive
            return self._send_device_notice()

    def encode(self, body):
        if CONST_VERSION_3 == self.version:
            return base64.encodestring(body)
        else:
            return body

    def decode(self, body):
        if CONST_VERSION_3 == self.version:
            return base64.decodestring(body)
        else:
            return body

def headles(local_ip,dest_ip,core,device,siteName,agent_version):
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM) 
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    #sock.bind((local_ip,0))
    #sock.setblocking(0)
    #sock.connect(dest_ip)
    vfw=vfw_simulation(local_ip,core,device,siteName,sock,agent_version)
    while True:
        try:
            sock.fileno()
        except socket.error :
            print("%-15s %s Socket is closed"%(local_ip,sock.getsockname()))
            break
        data = None
        try:
            with gevent.Timeout(10,False):
               data,address=sock.recvfrom(1024)
        except :
            pass
        if data is None :
            pack=vfw.send_pack(vfw.smcRunTime)
            if type(pack) == tuple :
                for i in range(len(pack)):
                    sock.sendto(pack[i],dest_ip)
            else :
                sock.sendto(pack,dest_ip)
            #print("no response from %s  connect to %s "%(str(sock.getsockname()),str(dest_ip)))
        else :
            pack=vfw.unpack_header(data,sock)
            if type(pack) == tuple :
                for i in range(len(pack)):
                    sock.sendto(pack[i],dest_ip)
            print("%s have response from %s  connect to %s  ip :%s"%(time.strftime("%Y-%m-%d %H:%M:%S",time.gmtime()),str(sock.getsockname()),str(address),local_ip))
                    
def run_main(ip_list,dest_ip,core,device,siteName,agent_version):
    even=[]  #事件驱动，存放事件
    #gevent.joinall([
    #gevent.spawn(headles,ip_list[0],dest_ip,core),
    #gevent.spawn(headles,ip_list[1],dest_ip,core)
    #])
    for i in range(len(ip_list)):
        even.append(gevent.spawn(headles,ip_list[i],dest_ip,core,device,siteName[i],agent_version))
    gevent.joinall(even)

if __name__ == '__main__' :
    #配置smc服务器IP
    dest_ip='192.168.120.11'
    #dest_ip='192.168.125.10'
    port = 9070
    # 设置agent版本号
    agent_version = CONST_VERSION_3
    dest=(dest_ip,port)
    vwaf=0
    vfw=1
    #配置vfw使用的本地
    local_ip='172.18.12.1'
    core=4
    ip_num=1000
    ip_list=ip_change(local_ip,ip_num)
    site_list=get_siteName('site.test.com',ip_num)
   # pdb.set_trace()
    run_main(ip_list,dest,core,vwaf,site_list,agent_version)
